# packages -
using LinearAlgebra

# my codes -
include("Expa.jl")
include("Stoichiometric.jl")
include("Parser.jl")